# PaperclipClientBrowserExtension - `@amzn/paperclip-client-browser-extension`

## Installing and using the extension

### Chrome
- Open Chrome's [extension page](chrome://extensions) (`chrome://extensions`)
- Enable the "Developer mode" switch at the top right
- Select the "Load unpacked" button at the top left and select this project's folder
- Select the puzzle piece (extensions) icon to the right of the address bar and pin the Amazon Q extension
- Select the Amazon Q extension icon to open the sidebar

### Edge 

- Open Edge's [extension page](edge://extensions) (`edge://extensions`)
- Enable the "Developer mode" switch in the left pane
- Select the "Load unpacked" button at the top and select this project's folder
- Select the puzzle piece (extensions) icon to the right of the address bar
- Select the eye icon next to the Amazon Q extension to "Show in Toolbar"
- Select the Amazon Q extension icon to open the sidebar

### Firefox

- Open Firefox's [debugging page](about:debugging#/runtime/this-firefox) (`about:debugging#/runtime/this-firefox`)
- Click "Load Temporary Add-on..."
- Navigate to this project's root and select `manifest.json`
- Select the puzzle piece (add-ons) icon to the right of the address bar
- Select the gear icon to the right of the Amazon Q icon and select “Pin to Toolbar"
- Select the Amazon Q add-on to open the popup

### Microsoft Word Web

Note that you have to host the extension locally.

- Log into https://www.office.com
- Open a word document in a new tab
- Click "Add-ins" in the ribbon then "More Add-ins"
- Click "MY ADD-INS" then "Manage My Add-ins" then "Upload My Add-in"
- Navigate to this project's root and select `manifest.xml`
- Select Amazon Q extension icon in the ribbon

### Microsoft Outlook Web

Note that you have to host the extension locally.
Note that changing the manifest version or installing for the first time in a new account causes a multi hour delay in the extension showing up.

- Log into https://www.office.com
- Open https://aka.ms/olksideload in a new tab
- Click "My add-ins"
- Navigate to "Custom Addins" and click "Add a custom add in"
- Navigate to this project's root and select `manifest.xml`
- Select Amazon Q extension icon under the "Apps" icon on an opened email

### iOS App

- Run `bb build` to compile source into `dist-ios/`.
- Run `brazil-build run:ios` to launch project in Xcode.

### Android App

- Run `bb build` to compile source into `dist-android/`.
- Run `brazil-build run:android` to launch the project in Android Studio.

## Using the extension
- Right click on a webpage and select "Summarize Page" or highlight text and select "Summarize Text"
- Provide text into the text box at the bottom and hit Enter or click "Submit"
- Switch backends by selecting the radio inputs at the top
- Reset your session by selecting "Reset"

## Developing and running locally

Build scripts are tested on **Mac**. These will probably work on Linux and Windows Subsystem for Linux, but I have not tested them.

- Run `bb install` to install package dependencies
- Run `bb build` to compile source into `dist/`
- For debug builds:
  - Run: `NODE_ENV=dev bb package` 
  - Debug artifacts will be created at `build/debug/{chromium, chromium-webstore, firefox}-extension/`
    - Note: For local development on chrome, use `chromium` build
- For release builds:
  - Run: `bb package`
  - Release artifacts will be created at `build/release/{chromium, chromium-webstore, firefox}-extension.zip`
- For stages other than prod, include `STAGE=[stage]` to the package step e.g. `STAGE=gamma NODE_ENV=dev bb package`
- For locally hosting the extension:
  - Run `bb devcert`
  - Set your target & user in `server.cjs`.
  - Run `bb server`
- Continue the process with the steps listed above.
