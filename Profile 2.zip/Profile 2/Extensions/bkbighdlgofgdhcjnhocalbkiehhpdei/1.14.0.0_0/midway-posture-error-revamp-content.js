function tryConnection() {
    var numRetries = 3;
    if (myPort == null) {
        while (myPort == null && numRetries > 0) {
            myPort = browser.runtime.connect();
            myPort.onMessage.addListener(contentPortMessageListener);
            myPort.onDisconnect.addListener(contentPortDisconnectListener);
            numRetries--;
        }
    }
    return (myPort != null);
}

function contentPortMessageListener(m) {
    if (m.type == "pollMidwayRevampFlagResult") {
        if (m.message != null) {
            shouldRevampPostureErrorPages = m.message;
            if (shouldRevampPostureErrorPages) {
                try {
                    if (window?.requestIdleCallback) {
                        if (!is_new_ui()) {
                            setTimeout(update_error_messaging, 100);
                        }
                    }
                } catch (e) {
                    console.error("An issue was encountered while trying to reformat the posture error page. " + e);
                }
            } else {
                console.log("shouldRevampPostureErrorPages was set to false, so the revamped posture page will not be displayed.");
            }
        }
    }
}

function contentPortDisconnectListener(p) {
    myPort = null;
}

function requestMidwayRevampFeatureFlag() {
    if (tryConnection()) {
        myPort.postMessage({type:"pollMidwayRevampFlag"});
    }
}

/**
 * this function will get the new revised error message for the revamped posture error page
 * @param error_message
 */
function get_revised_error_messages(error_message) {
    //Compliance based errors
    if ((error_message.includes("missing") || error_message.includes("non_compliant")) && !error_message.includes("platform")) {
        return '<a href="acme://launchacmeui">Click here to launch ACME</a> to check compliance and take action on pending updates.<br>';
    }
    //Time sync errors
    if (error_message.includes("used_too_late") || error_message.includes("used_too_soon")) {
        return "Please ensure that date and time are accurately set in your settings, wait a few seconds and refresh the page.<br>";
    }
    //jwt errors
    if (error_message.includes("jwt_verification_failed") || error_message.includes("You did not present a posture cookie.")) {
        return 'Please make sure ACME is registered and running, <a href="acme://launchacmeui">Click here to launch ACME</a> to confirm.<br>';
    }
    //if none of these strings are in the error message then there is no text to add.
    return "NONE";
}

function convert_cookie_string_to_dict(cookie_str) {
    cookie_str = cookie_str.split('; ');
    var result = {};
    for (var i = 0; i < cookie_str.length; i++) {
        var cur = cookie_str[i].split('=');
        result[cur[0]] = cur[1];
    }
    return result;
}

function is_new_ui() {
    //get all the cookies and convert the string into a dictionary
    const allCookies = convert_cookie_string_to_dict(document.cookie);
    //look through all the cookies for one that has the key value of "ui-preference"
    if ("ui-preference" in allCookies) {
        //if the value is "newui" return true
        if (allCookies["ui-preference"] === "newui") {
            return true;
        }
    }
    return false;
}

function update_error_messaging() {
    try {
        let originalElement = document.getElementById("message");
        let aboveElement = originalElement.previousElementSibling;
        if (aboveElement != null && aboveElement.id === "acca_midway_posture_error_message") {
            console.log("This Midway error page has already been reformatted");
            return;
        }
        let newElement = document.createElement('p');
        let newPostureErrorMessage = get_revised_error_messages(originalElement.textContent);
        if (newPostureErrorMessage !== "NONE") {
            newElement.innerHTML = newPostureErrorMessage;
            newElement.id = "acca_midway_posture_error_message";
            newElement.style.fontWeight = "bold";
            newElement.style.whiteSpace = "nowrap";
            newElement.style.boxSizing = "border-box";
            newElement.style.margin = "5px";
            newElement.style.marginBottom = "1rem";
            originalElement.insertAdjacentElement('beforebegin', newElement);
        } else {
            console.log("We could not find accompanying text for this kind of error");
        }
    } catch (e) {
        console.log("We were unable to get an HTML element with ID, message. " + e);
    }
}

var myPort = null;
let shouldRevampPostureErrorPages = null;

try {
    tryConnection();
    requestMidwayRevampFeatureFlag();
} catch (e) {
    console.warn("AEA Extension: ", e.stack);
}

module.exports = {
    update_error_messaging: update_error_messaging,
    convert_cookie_string_to_dict: convert_cookie_string_to_dict,
    is_new_ui: is_new_ui
}
