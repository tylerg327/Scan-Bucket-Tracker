import {getLocal} from "./storage.js"
/**
* If debug is enabled in local storage, write to console
* @param str : string to log to console.
*/
export function logToConsole(str) {
	getLocal("debug").then(r => {
		if(r.debug) {
			console.log(str);
		}
	});
}

/**
 * if debug is enabled in local storage, write error to console
 * @param {string} error 
 */
export function onError(error) {
	logToConsole(`Error: ${error}`);
}

/**
 * sleep for ms
 * @param {int} ms 
 */
export async function sleep(ms) {
	await new Promise(r => setTimeout(r, ms));
}

/**
 * Debounce subsequent calls to func
 * See: https://www.freecodecamp.org/news/javascript-debounce-example/
 * @param {*} func 
 * @param {*} timeout 
 * @returns 
 */
export function debounce(func, timeout=300) {
	logToConsole("debounce declared")
	let timer;
  	return () => {
    	clearTimeout(timer);
    	timer = setTimeout(() => { 
			logToConsole("debounce applied")
			func.apply(this); 
		}, timeout);
  	};
}

/**
 * Function to leverage URL library to get id_token query parameter
 * @returns id_token or null
 */
export function parseIdTokenFromCallbackUrlIfItExists(callbackUrl) {
	let url = null;
	try {
		url = new URL(callbackUrl);
	} catch (e) {
		return null;
	}
	const idToken = url.searchParams.get('id_token');
	return idToken;
}

