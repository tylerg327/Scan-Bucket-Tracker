import { getLocal, deleteCookie } from "./storage.js";
import { logToConsole, onError } from "./utils.js";

/**
 * Function to reload tabs. Tabs which have been reloaded more than 'maxReloadAuthTabCount' times do not get reloaded again.
 * The tabs which get reloaded have the searchParam 'acmeRefreshed' set to 1 in their url.
 * @param {Array} tabs to reload.
 */
async function reloadTabs(tabs) {
	let maxReloadAuthTabCount = (await getLocal("midway_max_reload")).midway_max_reload;
	for  (let tab of tabs) {
		var numReloads;
		let numReloadTriesCookie = await browser.cookies.get({name: 'reloadAuthTabCount', url: tab.url});
		if (numReloadTriesCookie) {
			numReloads = parseInt(numReloadTriesCookie.value);
		}
		else{
			numReloads = 0;
		}

		if (numReloads >= maxReloadAuthTabCount) {
			logToConsole(`Reload count exceeded, stopping reload for tab ${tab.url}`);
			continue;
		}
		let acmeRefreshedUrl = new URL(tab.url);
		if (acmeRefreshedUrl.searchParams.get('acmeRefreshed') !== '1') {
			acmeRefreshedUrl.searchParams.append("acmeRefreshed", 1)
		}
		if (numReloads > 0) {
            await deleteCookie({name: 'reloadAuthTabCount', url: tab.url});
        }
		numReloads++
        await setNumReloads(tab.url, numReloads);
		let reloading = browser.tabs.update(tab.id, {url: acmeRefreshedUrl.href});
		await reloading.then((tab) => onReloaded(tab.url), onError);
	}
}

/**
 * Function to reload all tabs which are matching the failed auth url patterns.
 */
export async function reloadFailedAuthTabs() {
	var tabsToReload = [];
    let authDomain = (await getLocal("auth_domains")).auth_domains;
    let midwayAuthPostureErrorPattern = (await getLocal("midway_posture_error_pattern")).midway_posture_error_pattern;
    let midwayAuthRedirectUrlPattern = (await getLocal("midway_redirect_url_pattern")).midway_redirect_url_pattern;
	for (let domain of authDomain) {
		tabsToReload.push(domain + midwayAuthPostureErrorPattern);
		tabsToReload.push(domain + midwayAuthRedirectUrlPattern);
	}
	var tabsMatchingFailedAuthUrlPatterns = await browser.tabs.query({ url: tabsToReload});
	await reloadTabs(tabsMatchingFailedAuthUrlPatterns);
}

/**
 * function to set the number of times a tab has been reloaded.
 * @param tabName
 * @param numReloads
 */
async function setNumReloads(tabName, numReloads) {
	logToConsole(`Setting number of reloads for ${tabName} to count: ${numReloads}`);
    await browser.cookies.set({name: 'reloadAuthTabCount', url: tabName, value: numReloads.toString()});
}

/**
 * Callback function for when a tab is reloaded successfully.
 * @param {string} tabName - name of the tab being reloaded.
 */
function onReloaded(tabName) {
	logToConsole(`Reloaded: ${tabName}`);
}