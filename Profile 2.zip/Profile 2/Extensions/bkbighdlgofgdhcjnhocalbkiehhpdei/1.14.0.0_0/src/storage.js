import { jwtDecode } from "../thirdparty/jwt-decode.js";
import { logToConsole, onError } from "./utils.js";

/**
 * Set default variables in local storage.
 */
export async function initVariables() {
	await setLocal({"native_app": "amazon_enterprise_access"});
	await setLocal({"default_cookie_name": "amazon_enterprise_access"});
	await setLocal({"presence_cookie_name": "aea_plugin_present"});
	await setLocal({"default_cookie_expiry": 900});
	await setLocal({"presence_cookie_expiry": 1209600});
	await setLocal({"presence_cookie_renew": 604800});
	await setLocal({"auth_domains": [
		"https://midway.aws.a2z.com",
		"https://midway.amazon.dev",
		"https://midway.aws.dev",
		"https://midway-auth-integ.us-east-1.amazon.com",
		"https://midway-auth-integ.aka.amazon.com",
		"https://midway-auth.amazon.com",
		"https://midway-auth-itar.amazon.com",
		"https://federate-dev.corp.amazon.com",
		"https://federate-int.corp.amazon.com",
		"https://federate.amazon.com",
	]});
	await setLocal({"presence_cookie_only_domains":[
		"https://www.amazon.jobs", 
		"https://amazon.jobs", 
		"https://dev.amazon.jobs", 
		"https://integ.amazon.com",
		"https://corp.amazon.com",
		"https://essportal-preprod.amazon.com",
		"https://amazon.work",
		"https://bingo.aws.dev",
		"https://builder.aws.com"
	]});
	await setLocal({"cookie_interval": 1});
	await setLocal({"config_interval": 60});
	await setLocal({"config_received": false});
	await setLocal({"monitor_interval": 5});
    await setLocal({"health_interval": 20});
	await setLocal({"tt_link": "https://tt.amazon.com/"});
	await setLocal({"extension_url": "https://browser-plugin.amazon-corp.com/"});
	//await setLocal({"debug": true});
	await setLocal({"device_id": createUuidv4()});
	await setLocal({"patch_blacklist": []});
	await setLocal({"auth_tabs": []});
	await setLocal({"midway_redirect_url_pattern": "/SSO/redirect*"});
	await setLocal({"midway_max_reload": 5});
	await setLocal({"midway_posture_error_pattern": "/posture-error*"});
	await setLocal({"shouldRevampPostureErrorPages": false});
	const opfTenantDomains = await getLocal("opf_tenant_domains");
	if (!opfTenantDomains) {
		await setLocal({"opf_tenant_domains": []}); // TODO: Get a list of default domains from OPF team.
	}

	const isInternalFeatureEnabled = await getLocal("isInternalFeatureEnabled");
	if (!isInternalFeatureEnabled) {
		await setLocal({"isInternalFeatureEnabled": false});
	}
	const enableMcsIntegration = await getLocal("enable_mcs_integration");
	if (!enableMcsIntegration || Object.keys(enableMcsIntegration).length === 0) {
		await setLocal({"enable_mcs_integration": false});
	}
}

/**
 * gets variable from local storage
 * @param {*} variable 
 * @returns 
 */
export function getLocal(variable) {
	return browser.storage.local.get(variable);
}

/**
 * sets variable in local storage
 * @param {*} variable 
 */
export function setLocal(variable) {
	return browser.storage.local.set(variable);
}

/**
 * removes keys (array or single key) from local storage
 * @param {*} keys 
 */
export function removeLocal(keys) {
	return browser.storage.local.remove(keys);
}

async function setPresenceCookie(ad, presence_cookie_name, store, time, presence_cookie_renew, presence_cookie_expiry) {
	// AEA long lived AEA browser cookie
	// see: https://sim.amazon.com/issues/V1037639268
	var presenceCookie = await browser.cookies.get({
		url: ad,
		name: presence_cookie_name,
		storeId: store.id
	});

	var replaceCookie = false;
	var manifest = browser.runtime.getManifest();
	var aea_presence = btoa(`{ "plugin_version": "${manifest.version}" }`);

	if (presenceCookie) {
		logToConsole(`Found existing presenceCookie at ${ad}`)
		var remainingTime = presenceCookie.expirationDate - time;
		var pcv = atob(presenceCookie.value);
		var pvMatch = (/"plugin_version": "(.*)"/g).exec(pcv);
		var pv = undefined;

		if (pvMatch.length > 1) {
			pv = pvMatch[1];
		}
		//logToConsole(`pv: ${pv} mv: ${manifest.version}, eq: ${pv == manifest.version}`)
		//logToConsole(`rem time: ${remainingTime}, renew: ${presence_cookie_renew}, eq: ${remainingTime < presence_cookie_renew}`)
		replaceCookie = pv != manifest.version || remainingTime < presence_cookie_renew;
	} else {
		logToConsole(`Presence cookie not found in ${ad}`);
	}

	if (!presenceCookie || replaceCookie) {
		logToConsole(`setting AEA plugin presence cookie: plugin_version=${manifest.version} not existed: ${!presenceCookie},replace: ${replaceCookie}`);
		var pExpiry = time + presence_cookie_expiry;
		try {
			await browser.cookies.set({
				url: ad,
				domain: ad.replace("https://", ""),
				name: presence_cookie_name,
				value: aea_presence,
				expirationDate: pExpiry,
				sameSite: "no_restriction",
				secure: true,
				storeId: store.id
			});
		} catch (err) {
			onError(`setCookie: Could not set AEA plugin presence cookie: ${err}`);
		}
	}
}

/*
* Function to set posture cookie with jwt and long lived 
* AEA presence cookie (Since version 1.4.8.3) every x seconds
*/
export async function setCookie(jwt, auth_domains=[]) {
	logToConsole("Setting JWT cookies and Presence Cookies");
	var logStores = await browser.cookies.getAllCookieStores();
	var presence_cookie_name = (await getLocal("presence_cookie_name")).presence_cookie_name;
	var presence_cookie_renew = (await getLocal("presence_cookie_renew")).presence_cookie_renew;
	var presence_cookie_expiry = (await getLocal("presence_cookie_expiry")).presence_cookie_expiry;
	var presence_cookie_only_domains = (await getLocal("presence_cookie_only_domains")).presence_cookie_only_domains;
	var default_cookie_expiry = (await getLocal("default_cookie_expiry")).default_cookie_expiry;
	var default_cookie_name = (await getLocal("default_cookie_name")).default_cookie_name;
	for (let store of logStores) {
		if (auth_domains.length == 0) {
			auth_domains = (await getLocal("auth_domains")).auth_domains;
		}
		// Set Presence Cookie for non-auth domains which require it
		for (let ad of presence_cookie_only_domains) {
			var now = new Date();
			var time = Math.round(now.getTime() / 1000);
			await setPresenceCookie(ad, presence_cookie_name, store, time, presence_cookie_renew, presence_cookie_expiry);
		}
		for (let ad of auth_domains) {
			now = new Date();
			time = Math.round(now.getTime() / 1000);
			await setPresenceCookie(ad, presence_cookie_name, store, time, presence_cookie_renew, presence_cookie_expiry);

			if (jwt) {
				var expireTime = time + default_cookie_expiry;
				try {
					await browser.cookies.set({
						url: ad,
						domain: ad.replace("https://", ""),
						name: default_cookie_name,
						value: jwt,
						secure: true,
						expirationDate: expireTime,
						sameSite: "no_restriction",
						storeId: store.id
					});
					logToConsole(`Successfully set jwt cookie at ${ad}`)
				}
				catch (err) {
					onError(`setCookie: Could not set jwt cookie at ${ad}: ${err}`)
				}
			}
		}
	}
	// successfully set cookie on domains, setting last_set_cookie in local storage
	await setLocal({"last_set_cookie": jwt});
}

/**
* Replace cookies expired with base64 encoded cookie.
* Data in that cookie will be as following
* "{'acmeGenerated':0, 'guid':'<<guid retried from local storage>>'}"
* @param {Array} cookies: List of cookies with same name defined in 'var cookieName'.
*/
async function replaceExpiredCookiesWithBase64Cookies(cookies) {
	var expiredCookieExist = false;
	var domains = []
	var auth_domains = (await getLocal("auth_domains")).auth_domains;
	for (let cookie of cookies) {
		var cookieExpiryDate = cookie.expirationDate;
		var now = new Date();
		var currentEpochTime = Math.round(now.getTime() / 1000);
		if (cookieExpiryDate < currentEpochTime) {
			// Cookie is expired we need to set base64 encoded cookies
			expiredCookieExist = true;
			var ad = `https://${cookie.domain}`;
			ad in auth_domains ? domains.push(`https://${cookie.domain}`) : await deleteCookie({name: cookie.name, url: ad});
		}
	}
	if (expiredCookieExist) {
		await createBase64Cookies(domains);
	}
}

/**
 * Delete a cookie if we are not tracking it in authDomain
 * @param {*} cookie 
 */
export async function deleteCookie(cookie) {
	logToConsole(`Deleting expired cookie: ${cookie.url}`);
	await browser.cookies.remove(cookie).catch(err => onError(`deleteCookie: ${err}`));
}

/**
 * Convert json object to base64 encoded string.
 * @param {object} jsonObject : Object to convert into base64 encoded string.
 * @returns {string} base64 encoded string.
 */
function jsonObjectToBase64Str(jsonObject) {
	var base64Str = null;
	try {
		var jsonStr = JSON.stringify(jsonObject);
		base64Str = btoa(jsonStr);
	} catch (err) {
		logToConsole("jsonObjectToBase64Str() : Unable to convert json object to base64 string due to error : " + err.message);
	}

	return base64Str;
}

/**
 * Generate version 4 uuid in recommended format.
 * @returns {string} uuid.
 */
function createUuidv4() {
	return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
		var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
		return v.toString(16);
	});
}

/**
* Function to create cookie with base64 encoded string as data.
* cookie data's base64 string will contain following payload
* "{'acmeGenerated':0, 'guid':'<<guid retried from local storage>>'}"
*/
export async function createBase64Cookies(auth_domains = []) {
	var cookieDataJson = { 
		'acmeGenerated': 0,
		'guid': (await getLocal("device_id")).device_id
	};
	var cookieDataBase64Enc = jsonObjectToBase64Str(cookieDataJson);
	await setCookie(cookieDataBase64Enc, auth_domains);
}

/**
* monitorCookies - Post update to ACME if no cookies are found in the object
* params: cookies- an array of cookies.Cookie
*/ 
export async function monitorCookies() {
    var cookie_name = (await getLocal("default_cookie_name")).default_cookie_name
	var logStores = await browser.cookies.getAllCookieStores()
	for (let store of logStores) {
		try {
			var cookies = await browser.cookies.getAll({
				name: cookie_name,
				storeId: store.id
			});
			if (cookies.length === 0) {
				// Generating Base64 cookies intially in case no cookie is present
				await createBase64Cookies();
			}
			else {
				// checking for expired cookies
				await replaceExpiredCookiesWithBase64Cookies(cookies);
			}
		} catch (e) {
			onError(`monitorCookies: ${e}`);
		}
	}
}

export async function monitorDomainCookies() {
	logToConsole("Starting Domain Cookie Monitor")
	var domains = (await getLocal("auth_domains")).auth_domains;
	for (let url of domains) {
		//strip https://
		var domain = url.replace("https://", "");
		logToConsole(`monitoring cookie size for domain: ${domain}`)
		var cookies = await browser.cookies.getAll({domain: domain});
		var size = 0;
		for (let cookie of cookies) {
			var blb = new Blob([cookie.value])
			size += blb.size
			logToConsole(`${cookie.name}: size: ${blb.size}`)
		}
		logToConsole(`total cookie size for domain (${domain}): ${size}`)
	}
	logToConsole("Domain Cookie Monitor END")
}

/**
 * Pull policy from managed storage. Config from ACME is prioritized.
 */
export async function extensionPolicyConfigCheck() {
	// Check to see if we've already received config from ACME
	// and make sure this is a chrome extension with storage permissions
	if (!(await getLocal("config_received")).config_received && chrome && chrome.storage && chrome.storage.managed) {
		chrome.storage.managed.get("aeaConfig", async (policy) => {
			if (chrome.runtime.lastError) {
				logToConsole("Unable to retrieve config from managed storage. Expected if this is firefox. " + chrome.runtime.lastError);
			}
			// Confirm we've received config, and that we haven't received config from ACME in the meantime
			else if (policy !== undefined && policy.aeaConfig !== undefined) {
				var aeaConfig = policy.aeaConfig;
				if ("cookie_refresh_interval" in aeaConfig) {
                    var interval_in_mins = Math.floor(aeaConfig["cookie_refresh_interval"]/60); //converting to mins
                    interval_in_mins = Math.max(1, interval_in_mins) // at least 1 min
                    if ((await getLocal("cookie_interval")).cookie_interval != interval_in_mins) {
                        logToConsole(`updating cookie refresh interval to ${interval_in_mins} from extension policy`)
                        await setLocal({"cookie_interval": interval_in_mins});
                    }
                }
                if ("healthcheck_interval" in aeaConfig) {
                    var interval_in_mins = Math.floor(aeaConfig["healthcheck_interval"]/60); //converting to mins
                    interval_in_mins = Math.max(1, interval_in_mins) // at least 1 min
                    if ((await getLocal("health_interval")).health_interval != interval_in_mins) {
                        await setLocal({"health_interval": interval_in_mins});
                    }
                }
                if ("config_refresh_interval" in aeaConfig) {
                    var interval_in_mins = Math.floor(aeaConfig["config_refresh_interval"]/60); //converting to mins
                    interval_in_mins = Math.max(1, interval_in_mins) // at least 1 min
                    if ((await getLocal("config_interval")).config_interval != interval_in_mins) {
                        logToConsole(`updating config refresh interval to ${interval_in_mins} from extension policy`)
                        await setLocal({"config_interval": interval_in_mins});
                    }
                    
                }
                "cookie_expiry" in aeaConfig && aeaConfig.cookie_expiry != (await getLocal("default_cookie_expiry")).default_cookie_expiry ? 
                    await setLocal({"default_cookie_expiry": aeaConfig.cookie_expiry}) :
                    logToConsole("config cookie_expiry in extension policy matches local");
                "auth_domain" in aeaConfig && aeaConfig.auth_domain != (await getLocal("auth_domains")).auth_domains ?
                    await setLocal({"auth_domains": aeaConfig.auth_domain}) :
                    logToConsole("auth_domains in extension policy match local");
								"opf_tenant_domains" in aeaConfig && aeaConfig.opf_tenant_domains != (await getLocal("opf_tenant_domains")).opf_tenant_domains ?
										await setLocal({"opf_tenant_domains": aeaConfig.opf_tenant_domains}) :
										logToConsole("opf_tenant_domains in extension policy match local");
								"isInternalFeatureEnabled" in aeaConfig && aeaConfig.isInternalFeatureEnabled != (await getLocal("isInternalFeatureEnabled")).isInternalFeatureEnabled ?
										await setLocal({"isInternalFeatureEnabled": aeaConfig.isInternalFeatureEnabled}) :
										logToConsole("isInternalFeatureEnabled in extension policy match local");
								if ("enable_mcs_integration" in aeaConfig) {
									if (aeaConfig.enable_mcs_integration != (await getLocal("enable_mcs_integration")).enable_mcs_integration) {
										await setLocal({"enable_mcs_integration": aeaConfig.enable_mcs_integration});
									} else {
										logToConsole("enable_mcs_integration in extension policy match local");
									}
								}
                "tt_link" in aeaConfig  && aeaConfig.tt_link != (await getLocal("tt_link")).tt_link ?
                    await setLocal({"tt_link": aeaConfig.tt_link}) :
                    logToConsole("tt_link in extension policy matches local");
                "patch_blacklist" in aeaConfig && aeaConfig.patch_blacklist != (await getLocal("patch_blacklist")).patch_blacklist ? 
                    await setLocal({"patch_blacklist": aeaConfig.patch_blacklist}) : 
                    logToConsole("patch_blacklist in extension policy matches local");
                "extension_url" in aeaConfig && aeaConfig.extension_url != (await getLocal("extension_url")).extension_url ? 
                    await setLocal({"extension_url": aeaConfig.extension_url}) : 
                    logToConsole("extension_url in extension policy matches local");
				"shouldRevampPostureErrorPages" in aeaConfig && aeaConfig.shouldRevampPostureErrorPages != (await getLocal("shouldRevampPostureErrorPages")).shouldRevampPostureErrorPages ?
					await setLocal({"shouldRevampPostureErrorPages": aeaConfig.shouldRevampPostureErrorPages}) :
					logToConsole("shouldRevampPostureErrorPages didn't change");
			}
		});
	}
}

/**
 * Function to check if any of the browser cookies are valid JWT generated by ACME.
 * @returns {boolean} - true if a valid JWT is found, false otherwise.
 */
export async function currentJWTValid() {
	try {
		var lastSetCookieValue = (await getLocal("last_set_cookie")).last_set_cookie;
		jwtDecode(lastSetCookieValue);
		return true;
	} catch (e) {
		return false;
	}
}
