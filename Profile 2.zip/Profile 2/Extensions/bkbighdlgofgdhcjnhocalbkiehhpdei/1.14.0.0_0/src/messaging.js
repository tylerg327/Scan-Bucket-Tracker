import { jwtDecode } from "../thirdparty/jwt-decode.js";
import { getLocal, setLocal, setCookie, removeLocal, currentJWTValid } from "./storage.js";
import { logToConsole, onError, sleep } from "./utils.js";
import { reloadFailedAuthTabs } from "./tabs.js";

/**
 * sends message to native host and retries for max_retries, waiting 15 seconds between retries
 * @param {*} cmd 
 * @param {*} max_retry 
 * @returns 
 */
export async function nativeMessageRetry(cmd, max_retry = 3, timeoutMs, logCommand = true) {
	
	var retry = 0;
	var app_name = (await getLocal("native_app")).native_app;
	if (logCommand) {
		logToConsole(`sending message ${cmd} to native host: ${app_name}`);
	}
	//will retry up to max_retry times
	var lastError;
	while (retry < max_retry) {
		try {
			logToConsole(`Attempt number: ${retry + 1} for command`);
			return await nativeMessageTimeout(cmd, timeoutMs, logCommand);
		} catch(e) {
			lastError = e;
			onError(`nativeMessageRetry: ${e}`);
			if (retry == max_retry) break;
			await sleep(500);
			retry++
		}
	}
	throw new Error(`failed to send message ${cmd} after ${max_retry} retries. Last error: ${lastError}`);
}

export async function nativeMessageTimeout(cmd, timeoutMs = 15000, logCommand = true) {
	logToConsole("Sending message via nativeMessageTimeout")
	var app_name = (await getLocal("native_app")).native_app;
	if (logCommand) {
		logToConsole(`sending message ${cmd} to native host: ${app_name}`);
	}
	return new Promise(async (resolve, reject) => {
		const responsePromise = browser.runtime.sendNativeMessage(app_name, new String(cmd));
		const timeoutPromise = new Promise((_, reject) => setTimeout(() => reject(new Error(`Did not receive response from native host after ${timeoutMs} ms`)), timeoutMs));
		try {
			const response = await Promise.race([responsePromise, timeoutPromise]);
			resolve(response);
		} catch (error) {
			reject(error);
		}
	});
}


/**
 * Function that polls native host for AEA is internal jwt
 * @returns jwt or null
 */
export async function getAeaIsInternalJwt() {
	try {
		var jwtPromise = nativeMessageRetry("getAeaIsInternalJwt", 1);
		var timeoutPromise = new Promise((resolve, reject) => {
			setTimeout(() => {
				reject(new Error("Timeout error"));
			}, 5000);
		});
		var msg = await Promise.race([jwtPromise, timeoutPromise]);
		const jwt = msg["Jwt"];
		return jwt;
	} catch (e) {
		onError(`getAeaIsInternalJwt: ${e}`);
		return null;
	}
}

/**
 * Function that polls configuration from Native host
 */
export async function getConfig() {
	try {
		var msg = await nativeMessageRetry("getConfig");
		logToConsole("received configuration from native host");
		await setLocal({"config_received": true});
		if ("cookie_refresh_interval" in msg) {
			var interval_in_mins = Math.floor(msg["cookie_refresh_interval"]/60); //converting to mins
			interval_in_mins = Math.max(1, interval_in_mins) // at least 1 min
			if ((await getLocal("cookie_interval")).cookie_interval != interval_in_mins) {
				await setLocal({"cookie_interval": interval_in_mins});
			}
		}
		if ("healthcheck_interval" in msg) {
			var interval_in_mins = Math.floor(msg["healthcheck_interval"]/60); //converting to mins
			interval_in_mins = Math.max(1, interval_in_mins) // at least 1 min
			if ((await getLocal("health_interval")).health_interval != interval_in_mins) {
				await setLocal({"health_interval": interval_in_mins});
			}
		}
		if ("config_refresh_interval" in msg) {
			var interval_in_mins = Math.floor(msg["config_refresh_interval"]/60); //converting to mins
			interval_in_mins = Math.max(1, interval_in_mins) // at least 1 min
			if ((await getLocal("config_interval")).config_interval != interval_in_mins) {
				await setLocal({"config_interval": interval_in_mins});
			}
			
		}
        "cookie_expiry" in msg && msg.cookie_expiry != (await getLocal("default_cookie_expiry")).default_cookie_expiry ? 
            await setLocal({"default_cookie_expiry": msg.cookie_expiry}) :
            logToConsole("config cookie_expiry matches local");
				"isInternalFeatureEnabled" in msg && msg.isInternalFeatureEnabled != (await getLocal("isInternalFeatureEnabled")).isInternalFeatureEnabled ?
						await setLocal({"isInternalFeatureEnabled": msg.isInternalFeatureEnabled}) :
						logToConsole("isInternal feature enablement didn't change");
		/** TODO: Temporarily disabling auth domains from config since we can change reduce this to subset defined in storage.js
		    before doing so we need to deploy firefox/chrome extensions and ensure penetration */
		//"auth_domain" in msg && msg.auth_domain != (await getLocal("auth_domains")).auth_domains ?
        //    await setLocal({"auth_domains": msg.auth_domain}) :
        //    logToConsole("auth_domains didn't change");
		"opf_tenant_domains" in msg && msg.opf_tenant_domains != (await getLocal("opf_tenant_domains")).opf_tenant_domains ?
						await setLocal({"opf_tenant_domains": msg.opf_tenant_domains}) :
						logToConsole("opf_tenant_domains didn't change");
		"tt_link" in msg  && msg.tt_link != (await getLocal("tt_link")).tt_link ?
            await setLocal({"tt_link": msg.tt_link}) :
            logToConsole("tt_link didn't change");
		if ("enable_mcs_integration" in msg) {
			if (msg.enable_mcs_integration != (await getLocal("enable_mcs_integration")).enable_mcs_integration) {
				await setLocal({"enable_mcs_integration": msg.enable_mcs_integration});
			} else {
				logToConsole("enable_mcs_integration didn't change");
			}
		}
		"patch_blacklist" in msg && msg.patch_blacklist != (await getLocal("patch_blacklist")).patch_blacklist ? 
            await setLocal({"patch_blacklist": msg.patch_blacklist}) : 
            logToConsole("patch blacklist didn't change");
		"extension_url" in msg && msg.extension_url != (await getLocal("extension_url")).extension_url ? 
            await setLocal({"extension_url": msg.extension_url}) : 
            logToConsole("extension_url didn't change");
		"shouldRevampPostureErrorPages" in msg && msg.shouldRevampPostureErrorPages != (await getLocal("shouldRevampPostureErrorPages")).shouldRevampPostureErrorPages ?
			await setLocal({"shouldRevampPostureErrorPages": msg.shouldRevampPostureErrorPages}) :
			logToConsole("shouldRevampPostureErrorPages didn't change");
	} catch(e) { 
		var errMsg = `Config could not be fetched from native host. Error: ${e}`
		onError(`getConfig: ${errMsg}`) 
	}
}

/**
 * polls native host for health check, if p is provided response is sent to content script
 * @param {*} p 
 */
export async function healthCheck(p) {
	try {
		var msg = await nativeMessageRetry("healthCheck", 1);
		logToConsole("received a health check from native host");
		browser.contextMenus.update("perform-health-check", {
			title: "Check health status (Last checked " + new Date(new Date().getTime()).toLocaleTimeString() + ")"
		});
		if (p) {
			for (var key in msg) {
				sendHealthStatusToContentScript(p, msg, key);
			}
		}
	} catch (e) {
		var errMsg = `Error performing health check: ${e}`;
		onError(`healthCheck: ${errMsg}`);

	}
}

/**
 * Method polls native host for acme data and sets device id in local storage
 */
export async function pollJwt(p, noRetry) {
	try {
		let numRetry = 3;
		if (noRetry) {
			numRetry = 1;
		}

		let msg = await nativeMessageRetry("getAcmeData", numRetry);
		//If we have no previously valid JWT, reload failed auth tabs
		let validJWTFound = await currentJWTValid();
		await setCookie(msg["Jwt"]);
		if (!validJWTFound) {
			await reloadFailedAuthTabs();
		}
		logToConsole("received jtw from native host");

		var decoded = jwtDecode(msg["Jwt"]);
		if ((await getLocal("device_id")).device_id != decoded["device_id"]) {
			setLocal({"device_id": decoded["device_id"]});
		}
		if (p) {
			let pollJwtResult = {jwtInStore : true, jwtMessage: "success"};
			p.postMessage({ message: pollJwtResult, type: "PollJwt" });
		}
	} catch (e) {
		let errMsg = `Unable to get jwt from native host: ${e}`
		onError(`pollJwt: ${errMsg}`);
		if (p) {
			let pollJwtResult = {jwtInStore : false, jwtMessage: errMsg};
			p.postMessage({ message: pollJwtResult, type: "PollJwt" });
		}
	}
}

function generateRandomTransactionId() {
	return crypto.randomUUID();
}

export function sendNativePortMessage(np, message, timeoutMs = 2000) {
	logToConsole("Sending message via persistent native port.")
	const transactionId = generateRandomTransactionId();
	let promise = new Promise((resolve, reject) => {
		const listener = (response) => {
			if (response.NativeMessagingTransactionId === transactionId) {
				np.onMessage.removeListener(listener);
				if (response.Status === "Success") {
					resolve(response);
				} else {
					reject(new Error(`Error communicating with native host: ${response.Status}`));
				}
			}
		};
		np.onMessage.addListener(listener)
		if (timeoutMs) {
			setTimeout(() => {
				const timeoutException = new Error(`Timeout error: Did not receive response from native host after ${timeoutMs} ms`);
				np.onMessage.removeListener(listener);
				reject(timeoutException);
			}, timeoutMs);
		}
	});
	np.postMessage(new String(`${message} --native-messaging-transaction-id ${transactionId}`));
	return promise;
}

export async function checkMcsIntegrationEnabledAndPostMessageIfNot(p, responseType) {
	try {
		const enableMcsIntegration = (await getLocal("enable_mcs_integration")).enable_mcs_integration;
		if (!enableMcsIntegration) {
			logToConsole(`MCS integration is not enabled. Returning. enableMcsIntegration: ${enableMcsIntegration}`);
			p.postMessage({ message: {"Status": `Failed - MCS integration is not enabled`, "ResultCode": 31}, type: responseType });
			return false;
		}
		return true;
	} catch(e) {
		logToConsole(`Error getting enableMcsIntegration from local storage`);
		p.postMessage({ message: {"Status": `Failed - Error getting enableMcsIntegration from local storage`, "ResultCode": 32}, type: responseType });
		return false;
	}
}


export async function setCookieIfAcmeWasUpdatedToProvideNativeMessagingTransactionIds() {
	try {
		logToConsole("Checking if responses mirror requested transaction ID")
		const response = await nativeMessageTimeout("getMcsSessionKeyPairPublicKeyAndKeyId --native-messaging-transaction-id 'abcd'", 1000, true);
		if (response.type != "getMcsSessionKeyPairPublicKeyAndKeyId") {
			logToConsole("An unexpected response was received")
			return
		}
		if (response.NativeMessagingTransactionId === "abcd") {
			logToConsole("Native messaging transaction IDs are supported")
			await setLocal({"acme_supports_transaction_ids": true});
		} else {
			logToConsole("Native messaging transaction IDs are not supported")
			await setLocal({"acme_supports_transaction_ids": false});
		}
	} catch (error) {
		logToConsole(`Error setting cookie if ACME was updated to provide native messaging transaction IDs - ${error}`);
	}
}

/*
* Respond to content script with the health status received from the native host.
*/
export function sendHealthStatusToContentScript(p, messageObject, keyword) {
	var response = { EnterpriseAccessExtensionHealthStatus: {} };

	// if the key is true
	if (messageObject[keyword]) {
		response.EnterpriseAccessExtensionHealthStatus[keyword] = true;
	}
	else {
		response.EnterpriseAccessExtensionHealthStatus[keyword] = false;
	}
	p.postMessage(response);
}

/**
* Parse the message and open a window for Auth.
* @param message: Message from IDP.
*/
export async function openAuthWindow(message) {
	logToConsole("opening new auth window");
	try {
		var respObj = message.content;
		var url = null;
		if (respObj.status == 403 || respObj.status == 0) {
			url = respObj.location;
		}
		else if (respObj.status == 401) {
			url = respObj.step_up_methods[0].cap_url;
		}
		else {
			logToConsole("Invalid response from IDP.");
			return;
		}
	
		//Validate the window we are going to open. Match with authDomain.
		var auth_domains = (await getLocal("auth_domains")).auth_domains;
		if (auth_domains.includes(getBaseUrl(url))) {
			var creating = browser.windows.create({
				url: url,
				type: "normal",
				height: 800,
				width: 800
			});
			await creating.then(onAuthWindowCreated, onError);
		}
	} catch (e) {
		onError(`openAuthWindow: ${e}`);
	}
}

/**
* Set port as null on Disconnection so as to not post message on disconnected port and try again
* params p- Port Disconnection object which has details of the disconnection event.
*/
export function contentPortDisconnectListener(p) {
	logToConsole(`disconnected from content script in tab: ${p.sender.url}`)
}

/**
 * Whenever auth window is created persist it for single auth window logic
 * @param {*} windowInfo 
 */
async function onAuthWindowCreated(windowInfo) {
	await setLocal({"current_auth_tab": windowInfo.tabs[0].id});
	await setLocal({"current_auth_window": windowInfo.id});
}


function postAuthInline() {
	window.postMessage("auth_success", "*");
}

/**
 * Whenever auth window is removed, post message to all the tabs that needs to resume req to RP.
 */
export async function onAuthWindowRemoved() {
	await removeLocal(["current_auth_tab", "current_auth_window"]);
	var authTabs = (await getLocal("auth_tabs")).auth_tabs;
	for (let tab of authTabs) {
		try {
			await browser.scripting.executeScript({
				target: { tabId: tab },
				func: postAuthInline
			});
		} catch (e) {
			onError(e)
		}		
	}
	await setLocal({"auth_tabs": []});
}

/**
* Gets base url from a url string
* @param locationString : URL string
* @return type<string> base url with protocol and hostname.
*/
function getBaseUrl(locationString) {
	var pathArray = locationString.split('/');
	var protocol = pathArray[0];
	var host = pathArray[2];
	return protocol + '//' + host;
}
