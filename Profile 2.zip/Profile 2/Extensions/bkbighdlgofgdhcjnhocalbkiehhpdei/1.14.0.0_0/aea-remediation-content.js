/**
* @file Content script that runs on midway error page to facilitate AEA remediation steps.
*
* @author Sabarish Raghu <sbrg@amazon.com>
*/

//create a port that connects to background script.
var myPort = null;
var remediationConfig = {};
try
{
	tryConnection();
}
catch(e)
{
	console.warn("AEA Extension: ", e.stack);
}

// Connect to background script and query the Config and Auth Sucess local
// storage event
if(tryConnection())
{
	//Get configuration from background script
	myPort.postMessage({content: "",type: "pollConfig"});
}

/*
* Call back function that is called when Content script to background script connection is disconnected.
*/
function contentPortDisconnectListener(p)
{
	myPort = null;
}

function contentPortMessageListener(m)
{
	if(m.type == "Configuration")
	{
		if(m.message.remediationConfig!= null)
		{
			remediationConfig = m.message.remediationConfig;
            var objectToSend = {};
        	objectToSend.remediationConfig = remediationConfig;


    		if(navigator.userAgent.search("Firefox")>-1)
    		{
    			try{
    				objectToSendFirefox = cloneInto(objectToSend, document.defaultView);
    				window.dispatchEvent(new CustomEvent('FromContentScript',{detail:objectToSendFirefox}));
    			}
    			catch(e)
    			{
    				console.warn("AEA Extension: ", e.stack);
    			}
    		}
    		else{
    			window.dispatchEvent(new CustomEvent('FromContentScript',{detail:objectToSend}));
    		}
		}
	}
}
//Function that injects our remediation patching page script in to the midway error page.
function injectRemediationXHRPatch()
{
    //Inject the open id script in to the page.
    if(document.getElementById("aea-remediation-xhr-patch"))
    {
        //page is already patched.
        return;
    }

    //append a patchingutil/js page script in the page to identify any existing xhr overrides and check user setting of dafaultOff.
    var remediationScript = document.createElement("script");
    remediationScript.src = browser.runtime.getURL('/aea-remediation.xhr.js');
    remediationScript.id = "aea-remediation-xhr-patch";
    if(document.doctype && document.doctype.name === 'html' && document.getElementById("aea-remediation-xhr-patch") == null)
    {
        (document.head||document.documentElement).appendChild(remediationScript);
    }
}

//Function that tries to connect to background script with 3 retry attempts.
function tryConnection()
{
	var numRetries = 3;
	if(myPort == null)
	{
	  while(myPort == null && numRetries >0)
	  {
		myPort = browser.runtime.connect();
		myPort.onMessage.addListener(contentPortMessageListener);
		myPort.onDisconnect.addListener(contentPortDisconnectListener);
		numRetries--;
	  }
	}
	return (myPort !=null);
}

injectRemediationXHRPatch();
