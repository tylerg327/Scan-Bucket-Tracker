/**
* @file Content script that runs on Midway auth pages.
* cookie is in the cookie store.
* @author Aaron Lichtblau <alichtb@amazon.com>
*/

//create a port that connects to background script.
var myPort = null;
try
{
	tryConnection();
}
catch(e)
{
	console.warn("AEA Extension: ", e.stack);
}

/*
* Call back function that is called when Content script to background script connection is disconnected.
*/
function contentPortDisconnectListener(p)
{
	myPort = null;
}

/*
Receive message from extension
*/
function contentPortMessageListener(m) {
   if(m.type == "PollJwt")
   {
       if (m.message != null) {
           console.log("received jwt result from extension, sending event to page script");
           window.dispatchEvent(new CustomEvent('checkPostureResult',{detail:m.message}));
       }
   }
   else if (m.type === "mcsSessionKeyPairPublicKeyReturned") {
        if (m.message != null) {
            objectToSend = {}
            objectToSend.status = m.message.Status;
            objectToSend.resultCode = m.message.ResultCode;
            objectToSend.encodedKey = m.message.EncodedKey;
            objectToSend.sessionKeyPairKeyId = m.message.SessionKeyPairKeyId;
            if (navigator.userAgent.search("Firefox") > -1) {
                objectToSend = cloneInto(objectToSend, document.defaultView);
            }
            window.dispatchEvent(new CustomEvent('mcsSessionKeyPairPublicKeyReturned',{detail: objectToSend}));
        }
    }
    else if (m.type === "sessionTokenReturned") {
        if (m.message != null) {
            objectToSend = {}
            objectToSend.status = m.message.Status;
            objectToSend.resultCode = m.message.ResultCode;
			objectToSend.sessionToken = m.message.SessionToken;
            objectToSend.exp = m.message.Exp;
            if (navigator.userAgent.search("Firefox") > -1) {
                objectToSend = cloneInto(objectToSend, document.defaultView);
            }
            window.dispatchEvent(new CustomEvent('sessionTokenReturned',{detail: objectToSend}));
        }
    }
    else if (m.type === "saveSessionTokenReturned") {
        objectToSend = {}
        objectToSend.status = m.message.Status;
        objectToSend.resultCode = m.message.ResultCode;
        if (navigator.userAgent.search("Firefox") > -1) {
            objectToSend = cloneInto(objectToSend, document.defaultView);
        }
        window.dispatchEvent(new CustomEvent('saveSessionTokenReturned',{detail: objectToSend}));
    }
    else if (m.type === "authorizeReturned") {
        objectToSend = {}
        objectToSend.status = m.message.Status;
        objectToSend.resultCode = m.message.ResultCode;
		objectToSend.callbackUrl = m.message.CallbackUrl;
        if (navigator.userAgent.search("Firefox") > -1) {
            objectToSend = cloneInto(objectToSend, document.defaultView);
        }
		window.dispatchEvent(new CustomEvent('authorizeReturned',{detail:objectToSend}));
    }
    else if (m.type === "deleteSessionTokenReturned") {
        objectToSend = {}
        objectToSend.status = m.message.Status;
        objectToSend.resultCode = m.message.ResultCode;
        if (navigator.userAgent.search("Firefox") > -1) {
            objectToSend = cloneInto(objectToSend, document.defaultView);
        }
        window.dispatchEvent(new CustomEvent('deleteSessionTokenReturned',{detail: objectToSend}));
    }
}

function injectMidwayAuthPagesWithPollJwtScript(scriptName) {
    console.log("Content script trying to inject page script into page source")
	//Inject the poll Jwt script into the page.
    if(document.getElementById(scriptName))
    {
        //page already has script.
        console.log("script already on page")
        return;
    }
    try {
        var script = document.createElement("script");
        script.src = browser.runtime.getURL('/midway-page-script-simulated-via-injection.js');
        script.id = scriptName;
        (document.head||document.documentElement).appendChild(script);
    }
    catch (e) {
        console.log(e)
    }
}

function listenForCheckPostureEvent() {
    console.log("Starting content script listener for checkPosture event...");
    function sendPollJwtToExtension(e){
        console.log("content script received message from page script to check Posture")
        if (tryConnection()) {
            //Poll Jwt from background script
            console.log("Sending message to background script through port to pollJWT...")
            myPort.postMessage({content: {"noRetry": true}, type: "pollJwt"});
        }
    }
    document.addEventListener('checkPosture', sendPollJwtToExtension, false);
}

//Function that tries to connect to background script with 3 retry attempts.
function tryConnection()
{
	var numRetries = 3;
	if(myPort == null)
	{
	  while(myPort == null && numRetries >0)
	  {
		myPort = browser.runtime.connect();
		myPort.onMessage.addListener(contentPortMessageListener);
		myPort.onDisconnect.addListener(contentPortDisconnectListener);
		numRetries--;
	  }
	}
	return (myPort !=null);
}

injectMidwayAuthPagesWithPollJwtScript("aea-poll-jwt-script");
listenForCheckPostureEvent();

const listenForMcsSessionKeyPairPublicKeyRequestedEvent = () => {
    console.log("Starting content script listener for mcsSessionKeyPairPublicKeyRequested event...");
    function sendMcsSessionKeyPairPublicKeyRequestedToExtension(e){
        console.log("content script received message from page script to get mcs session key pair public key")
        if (tryConnection()) {
            console.log("Sending message to background script through port to get mcs session key pair public key...")
            myPort.postMessage({type: "mcsSessionKeyPairPublicKeyRequested"});
        }
    }
    document.addEventListener('mcsSessionKeyPairPublicKeyRequested', sendMcsSessionKeyPairPublicKeyRequestedToExtension, false);
}

listenForMcsSessionKeyPairPublicKeyRequestedEvent();

const listenForSessionTokenRequestedEvent = () => {
    console.log("Starting content script listener for sessionTokenRequested event...");
    const hostname = window.location.hostname;
    function sendSessionTokenRequestedToExtension(e){
        console.log("content script received message from page script to get session token")
        if (tryConnection()) {
            console.log("Sending message to background script through port to get session token...")
            myPort.postMessage({content: {idpHostname: hostname}, type: "sessionTokenRequested"});
        }
    }
    document.addEventListener('sessionTokenRequested', sendSessionTokenRequestedToExtension, false);
}

listenForSessionTokenRequestedEvent();

const listenForSaveSessionTokenRequestedEvent = () => {
    console.log("Starting content script listener for saveSessionTokenRequested event...");
    const url = window.location.href;
    const hostname = window.location.hostname;
    function saveSessionTokenRequested(e){    
        console.log("content script received message from page script to get device posture token")
        const { sessionKeyPairKeyId } = e.detail;
        if (typeof(sessionKeyPairKeyId) !== 'string') {
            const errorMessage = "sessionKeyPairKeyId must be a string, not sending message to background script through port to save the posture token";
            contentPortMessageListener({ type: "saveSessionTokenReturned", message: { Status: `Failed - ${errorMessage}`, ResultCode: 33 } });
            return;
        }
        if (sessionKeyPairKeyId === "") {
            const errorMessage = "sessionKeyPairKeyId cannot be empty, not sending message to background script through port to save the posture token";
            contentPortMessageListener({ type: "saveSessionTokenReturned", message: { Status: `Failed - ${errorMessage}`, ResultCode: 33 } });
            return;
        }
        if (tryConnection()) {
            console.log("Sending message to background script through port to get device posture token...")
            myPort.postMessage({content: {idpUrl: url, idpHostname: hostname, sessionKeyPairKeyId: sessionKeyPairKeyId}, type: "saveSessionTokenRequested"});
        }
    }
    document.addEventListener('saveSessionTokenRequested', saveSessionTokenRequested, false);
}

listenForSaveSessionTokenRequestedEvent();


const listenForDeleteSessionTokenRequestedEvent = () => {
    const url = window.location.href;
    const hostname = window.location.hostname;
    function deleteSessionTokenRequested(){
        console.log("content script received message from page script to delete session token")
        if (tryConnection()) {
            console.log("Sending message to background script through port to delete session token...")
            myPort.postMessage({content: {idpUrl: url, idpHostname: hostname}, type: "deleteSessionTokenRequested"});
        }
    }
    document.addEventListener('deleteSessionTokenRequested', deleteSessionTokenRequested, false);
}

listenForDeleteSessionTokenRequestedEvent();

const listenForAuthorizeRequestedEvent = (e) => {
    console.log("Starting content script listener for authorizeRequested event...");
    function authorizeRequested(e) {
        console.log("content script received message from page script to perform authorization")
        if (tryConnection()) {
            if (window.location.host !== new URL(e.detail.authorizeUrl).host) {
                const errorMessage = "Host mismatch, not sending message to background script through port to perform authorization";
                contentPortMessageListener({ type: "authorizeReturned", message: { Status: `Failed - ${errorMessage}`, ResultCode: 34 } });
                return;
            }
            console.log("Sending message to background script through port to perform authorization...")
            myPort.postMessage({content: {authorizeUrl: e.detail.authorizeUrl}, type: "authorizeRequested"});
        }
    }
    document.addEventListener('authorizeRequested', authorizeRequested, false);
}

listenForAuthorizeRequestedEvent();