/**
* @file Content script that runs on Amazon internal pages.
* @author Mary Alula <maralula@amazon.com>
*/

//create a port that connects to background script.
var myPort = null;

try
{
	tryConnection();
}
catch(e)
{
	console.warn("Issue connecting to background script in SentryJS Content Script");
}

/*
* Call back function that is called when Content script to background script connection is disconnected.
*/
function contentPortDisconnectListener(p)
{
	myPort = null;
}

function contentPortMessageListener(m) {
	if (m.type === "authorizeReturned") {
		let objectToSend = {}
		let host = parseHost(m.message.CallbackUrl);
		objectToSend.status = m.message.Status;
		objectToSend.resultCode = m.message.ResultCode;
		objectToSend.host = host;
		
		//  Important Security Message:
		//  Do not return callbackURL if it includes id_token.
		//  We will set id_token for appropriate domain via background.js
		if (m.message.CallbackUrl && !m.message.CallbackUrl.includes("id_token")) {
			objectToSend.callbackUrl = m.message.CallbackUrl;
		}
		if (navigator.userAgent.search("Firefox") > -1) {
			objectToSend = cloneInto(objectToSend, document.defaultView);
		}
		window.dispatchEvent(new CustomEvent('authorizeReturnedSentryJS', {detail:objectToSend}));
	}
}
	

//Function that tries to connect to background script with 3 retry attempts.
function tryConnection()
{
	var numRetries = 3;
	if(myPort == null) {
		while(myPort == null && numRetries >0) {
			myPort = browser.runtime.connect();
			myPort.onMessage.addListener(contentPortMessageListener);
			myPort.onDisconnect.addListener(contentPortDisconnectListener);
			numRetries--;
		}
	}
	return (myPort !=null);
}

injectIntoWebsitesUsingSentryJS("sentryjs-api-injected");

const listenForAuthorizeRequestedSentryJSEvent = (e) => {
	console.log("Starting content script listener for authorizeRequested event...");
	function authorizeRequested(e) {
		console.log("content script received message from page script to perform authorization");
		
		if (tryConnection()) {
			if (isAuthCodeFlowUrl(e.detail.authorizeUrl) && currentLocationDoesNotMatchRedirectURI(e.detail.authorizeUrl)) {
				const errorMessage = "Auth Code Flow origin does not match redirect_uri, not sending message to background script through port to perform authorization";
				contentPortMessageListener({ type: "authorizeReturned", message: { Status: `Failed - ${errorMessage}`, ResultCode: 34 } });
				return;
			}
			console.log("Sending message to background script through port to perform authorization...")
			myPort.postMessage({content: {authorizeUrl: e.detail.authorizeUrl}, type: "authorizeRequestedSentryJS"});
		}
	}
	document.addEventListener('authorizeRequested', authorizeRequested, false);
}

function isAuthCodeFlowUrl(authorizeUrl) {
	if (!authorizeUrl) {
		return false;
	}
	return authorizeUrl.includes("response_type=code");
}

function currentLocationDoesNotMatchRedirectURI(authorizeUrl) {
	return window.location.host !== getRedirectURIHostFromAuthorizeUrlIfItExists(authorizeUrl)
}

listenForAuthorizeRequestedSentryJSEvent();

function getRedirectURIHostFromAuthorizeUrlIfItExists(authorizeUrl) {
	let url = null;
	try {
		url = new URL(authorizeUrl);
	} catch (e) {
		console.error(e);
		return null;
	}
	const parsedRedirectURI = url.searchParams.get('redirect_uri');

	if (parsedRedirectURI) {
		const decodedRedirectURI = decodeURI(parsedRedirectURI);
		const redirectURL = new URL(decodedRedirectURI);
		return redirectURL.host;
	} else {
		return null;
	}
}
	

function injectIntoWebsitesUsingSentryJS(scriptId) {
	console.log("SentryJS Content script trying to inject page script into page source")
	
	if (document.getElementById(scriptId)) {
		//page already has script.
		console.log("sentryjs-content-script: script already on page")
		return;
	}
	try {
		var script = document.createElement("script");
		script.src = browser.runtime.getURL('/sentryjs-api-injected.js');
		script.id = scriptId;
		(document.head||document.documentElement).appendChild(script);
	}
	catch (e) {
		console.log(e)
	}
}

function parseHost(callBackUrl) {
	if (!callBackUrl) {
		return null;
	}

	const url = new URL(callBackUrl);
	return url.host;
}


// Only export if we're in a NodeJS environment
if (typeof module !== 'undefined' && module.exports) {
	module.exports = {
		getRedirectURIHostFromAuthorizeUrlIfItExists,
		contentPortMessageListener,
		contentPortDisconnectListener,
		listenForAuthorizeRequestedSentryJSEvent
	};
} 