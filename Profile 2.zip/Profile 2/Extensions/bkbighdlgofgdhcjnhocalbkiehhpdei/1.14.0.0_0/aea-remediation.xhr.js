/**
* @file Page script that is injected on midway error page by AEA Extension to facilitate AEA remediation steps.
*
* @author Sabarish Raghu <sbrg@amazon.com>
*/

(function() {
    var remediationConfig = {};
    var xhr = XMLHttpRequest.prototype;
    var send = xhr.send;
    var open = xhr.open;

    //Listen to Configurations from Content script.
    window.addEventListener('FromContentScript', receiveMessageFromContentScript, false);

	function receiveMessageFromContentScript(e)
	{
        if(typeof e.detail.remediationConfig !='undefined')
        {
        	remediationConfig = e.detail.remediationConfig;
        }
	}

    //Patch xhr open method
    xhr.open = function(method, url) {
        this.url = url; // the request url
        return open.apply(this, arguments);
    }

    //Patch xhr send method
    xhr.send = function() {
        this.addEventListener('load', function() {
            if (this.url.includes('api/posture-validation')) {
                var postureValidationResponse = {};
                try{
                    postureValidationResponse = JSON.parse(this.response);
                }
                catch(e)
                {
                    console.warn("AEA Extension: Unexpected response from midway posture-validation API", e.stack);;
                }
                if(postureValidationResponse && postureValidationResponse.success == false)
                {
                    var currentOS = getOS();
                    //If there are remediation steps for the current OS and there is not already an injected steps, go for it.
                    if( currentOS in remediationConfig &&
                        postureValidationResponse.message in remediationConfig[currentOS] &&
                        document.getElementById('aea-remediation-steps') == null)
                    {
                        var dataDOMElement = document.createElement('div');
                        dataDOMElement.id = 'aea-remediation-steps';
                        dataDOMElement.innerHTML = remediationConfig[currentOS][postureValidationResponse.message];
                        dataDOMElement.style.margin = "20px";
                        dataDOMElement.style.textAlign = "left";
                        document.getElementById("helptext").parentNode.appendChild(dataDOMElement);
                    }
                }
            }
        });
        return send.apply(this, arguments);
    };

    /*
    * Get current running OS from browser userAgent
    */
    function getOS() {
      var userAgent = window.navigator.userAgent,
          platform = window.navigator.platform,
          macosPlatforms = ['Macintosh', 'MacIntel', 'MacPPC', 'Mac68K'],
          windowsPlatforms = ['Win32', 'Win64', 'Windows', 'WinCE'],
          iosPlatforms = ['iPhone', 'iPad', 'iPod'],
          os = null;

      if (macosPlatforms.indexOf(platform) !== -1) {
        os = 'macOS';
      } else if (iosPlatforms.indexOf(platform) !== -1) {
        os = 'iOS';
      } else if (windowsPlatforms.indexOf(platform) !== -1) {
        os = 'Windows';
      } else if (/Android/.test(userAgent)) {
        os = 'Android';
      } else if (!os && /Linux/.test(platform)) {
        os = 'Ubuntu';
      }

      return os;
    }
  })();
