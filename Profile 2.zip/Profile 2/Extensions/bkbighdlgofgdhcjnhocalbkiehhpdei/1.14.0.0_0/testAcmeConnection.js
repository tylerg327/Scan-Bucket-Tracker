/*
Content script that on run on EnterpriseAccess landing/testing page were loaded.
responsble for requestinig health status from ACME
*/


var port = browser.runtime.connect();

var ACMEReachable = false;
var Jwt = false;
var RegisteredWithKarl = false;


port.postMessage({type: "RequestHealthCheck"});
/*
 request health check every 60 seconds
*/
var healthCheckInsterval = setInterval(function(){
    // do your thing
    port.postMessage({type: "RequestHealthCheck"});
}, 60*1000);
// send message to local page
var sendEventToTestPage = function (eventName) {
  document.dispatchEvent(new CustomEvent(eventName));
}


/*
Receive message
*/
port.onMessage.addListener(function(m) {
   if(m.EnterpriseAccessExtensionHealthStatus!=null)
   {
     if(m.EnterpriseAccessExtensionHealthStatus["ACMEReachable"])
     {
       sendEventToTestPage('ACMEReachable');
       ACMEReachable = true;

     }

     if(m.EnterpriseAccessExtensionHealthStatus["Jwt"])
     {
       sendEventToTestPage('Jwt');
       Jwt = true;

     }

     if(m.EnterpriseAccessExtensionHealthStatus["RegisteredWithKarl"])
     {
       sendEventToTestPage('RegisteredWithKarl');
       RegisteredWithKarl = true;
     }
     if(RegisteredWithKarl && Jwt && ACMEReachable)
     {
       clearInterval(healthCheckInsterval);
     }
   }
});

sendEventToTestPage('EnterpriseAccessExtensionDetected');
