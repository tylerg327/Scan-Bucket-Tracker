/**
* @file Background script that runs on the background and does the following
* 1. Populate the posture cookie as required.
* 2. Communicates to content scripts to do health checks.
* 3. Communicates to content script to moderate single window auth logic by storing tab's auth states.
*
* @author Sabarish Raghu <sbrg@amazon.com>
*/
import "/thirdparty/browser-polyfill.min.js";
import { initVariables, getLocal, removeLocal, monitorCookies, extensionPolicyConfigCheck, monitorDomainCookies } from "./src/storage.js";
import { 
	getConfig, 
	healthCheck, 
	pollJwt, 
	getAeaIsInternalJwt, 
	setCookieIfAcmeWasUpdatedToProvideNativeMessagingTransactionIds, 
	checkMcsIntegrationEnabledAndPostMessageIfNot,
	openAuthWindow,
	onAuthWindowRemoved,
	contentPortDisconnectListener,
	sendNativePortMessage,
	nativeMessageTimeout,
} from "./src/messaging.js";
import { logToConsole, onError, debounce, parseIdTokenFromCallbackUrlIfItExists} from "./src/utils.js";
import { jwtDecode } from "../thirdparty/jwt-decode.js";

const checkAeaTokenExpiryAndRefreshIfAppropriatePeriodInMinutes = 5;

const removeOldRules = async () => {
	console.log("Removing all declarativeNetRequest rules.");
	const oldRules = await browser.declarativeNetRequest.getDynamicRules();
	const oldRuleIds = oldRules.map(rule => rule.id);
	await browser.declarativeNetRequest.updateDynamicRules({
		removeRuleIds: oldRuleIds
	});
	browser.storage.local.set({ aeaIsInternalJwtCurrentlyUsedInRules: null });
}

const addNewRulesToEnableIdentificationAsEmployee = async (aeaIsInternalJwt) => {

	var opf_tenant_domains = (await getLocal("opf_tenant_domains")).opf_tenant_domains;

	const newRules = opf_tenant_domains.map((domain, index) => {
		return {
			id: index + 1,
			priority: 1,
			action: {
				type: "modifyHeaders",
				requestHeaders: [
					{
						header: "x-aea-is-internal",
						operation: "set",
						value: aeaIsInternalJwt
					}
				]
			},
			condition: {
				urlFilter: `||${domain}`,
				resourceTypes: Object.values(browser.declarativeNetRequest.ResourceType) // all resource types
			}
		}
	});
	await removeOldRules();
	await browser.declarativeNetRequest.updateDynamicRules({
		addRules: newRules
	});
	logToConsole("Added new rules to enable identification as employee.");
}

//when extension is installed or updated set up context menu
browser.runtime.onInstalled.addListener(async () => {
	logToConsole("on installed")
	//Create the extension context menus
	browser.contextMenus.create({
		id: "about",
		title: "About AEA",
		contexts: ["all"]
	});
	browser.contextMenus.create({
		id: "refresh",
		title: "Refresh",
		contexts: ["all"]
	});
	browser.contextMenus.create({
		id: "perform-health-check",
		title: "Check health status",
		contexts: ["all"]
	});
	await initVariables();
	await getConfig();
	extensionPolicyConfigCheck();
	await pollJwt();
	await healthCheck();
	await checkAeaTokenExpiryAndRefreshIfAppropriate(); // will improve the speed with which rules are added on first install by ~5 minutes.
	setCookieIfAcmeWasUpdatedToProvideNativeMessagingTransactionIds();
});

//when browser is started up, initVariables,get config, set up context menu, and poll jwt
browser.runtime.onStartup.addListener(async () => {
	logToConsole("on startup")
	//Create the extension context menus
	browser.contextMenus.create({
		id: "about",
		title: "About AEA",
		contexts: ["all"]
	}, () => browser.runtime.lastError);
	browser.contextMenus.create({
		id: "refresh",
		title: "Refresh",
		contexts: ["all"]
	}, () => browser.runtime.lastError);
	browser.contextMenus.create({
		id: "perform-health-check",
		title: "Check health status",
		contexts: ["all"]
	}, () => browser.runtime.lastError);
	await initVariables();
	await getConfig();
	extensionPolicyConfigCheck();
	await pollJwt();
	await healthCheck();
	setCookieIfAcmeWasUpdatedToProvideNativeMessagingTransactionIds();
});

browser.alarms.get('getConfig').then(async (alarm) => {
	if (alarm) {
		await browser.alarms.clear('getConfig');
	}
	var interval = (await getLocal("config_interval")).config_interval
		interval = interval ? interval : 60
		browser.alarms.create('getConfig', {
			periodInMinutes: interval
		});
});

browser.alarms.get('pollJwt').then(async (alarm) => {
	if (alarm) {
		await browser.alarms.clear('pollJwt');
	}
	var interval = (await getLocal("cookie_interval")).cookie_interval
	interval = interval ? interval : 1
	browser.alarms.create('pollJwt', {
		periodInMinutes: interval
	});
});

browser.alarms.get('pollHealth').then(async (alarm) => {
	if (alarm) {
		await browser.alarms.clear('pollHealth');
	}
	var interval = (await getLocal("health_interval")).health_interval
	interval = interval ? interval : 1
	browser.alarms.create('pollHealth', {
		periodInMinutes: interval
	});

});

browser.alarms.get('checkAeaTokenExpiryAndRefreshIfAppropriate').then(async (alarm) => {
	if (alarm) {
		await browser.alarms.clear('checkAeaTokenExpiryAndRefreshIfAppropriate');
	}
	const { isInternalFeatureEnabled } = await browser.storage.local.get({ isInternalFeatureEnabled: false });
	if (!isInternalFeatureEnabled) {
		return;
	}
	const { userPrefersIdentificationAsEmployee } = await browser.storage.local.get({ userPrefersIdentificationAsEmployee: false });
	if (userPrefersIdentificationAsEmployee) {
		browser.alarms.create('checkAeaTokenExpiryAndRefreshIfAppropriate', {
			periodInMinutes: checkAeaTokenExpiryAndRefreshIfAppropriatePeriodInMinutes
		});
	}
});


browser.alarms.get('cookieMonitor').then(async (alarm) => {
	if (alarm) {
		await browser.alarms.clear('cookieMonitor');
	}
	var interval = (await getLocal("monitor_interval")).monitor_interval
	interval = interval ? interval : 5
	browser.alarms.create('cookieMonitor', {
		periodInMinutes: interval
	});
});

browser.alarms.get('cookieDomainMonitor').then(async (alarm) => {
	if (alarm) {
		await browser.alarms.clear('cookieDomainMonitor');
	}
	var interval = 5
	browser.alarms.create('cookieDomainMonitor', {
		periodInMinutes: interval
	});
});

browser.alarms.onAlarm.addListener(async (alarm) => {
	switch(alarm.name) {
		case 'getConfig':
			await getConfig();
			break;
		case 'pollJwt':
			await pollJwt();
			break;
		case 'cookieMonitor':
			await monitorCookies();
			break;
		case 'cookieDomainMonitor':
			await monitorDomainCookies();
			break;
		case 'pollHealth':
			await healthCheck();
			break;
		case 'checkAeaTokenExpiryAndRefreshIfAppropriate':
			await checkAeaTokenExpiryAndRefreshIfAppropriate();
			break;
		default:
			onError(`onAlarm.addListener -- alarm not recognized: ${alarm.name}`);
	}
});

//if changes to our intervals we need to clear and recreate our timers
browser.storage.local.onChanged.addListener(async (changes, area) => {
	if (changes.config_interval) {
		logToConsole("cookie config changed: restarting alarm");
		await browser.alarms.clear('getConfig');
		browser.alarms.create('getConfig', {
			periodInMinutes: changes.config_interval.newValue
		});
	}
	if (changes.cookie_interval) {
		logToConsole("cookie interval changed: restarting alarm");
		await browser.alarms.clear('pollJwt');
		browser.alarms.create('pollJwt', {
			periodInMinutes: changes.cookie_interval.newValue
		});
	}
	if (changes.monitor_interval) {
		logToConsole("cookie monitor changed: restarting alarm");
		await browser.alarms.clear('cookieMonitor');
		browser.alarms.create('cookieMonitor', {
			periodInMinutes: changes.monitor_interval.newValue
		});
	}
	if (changes.health_interval) {
		logToConsole("health interval changed: restarting alarm");
		await browser.alarms.clear('pollHealth');
		browser.alarms.create('pollHealth', {
			periodInMinutes: changes.health_interval.newValue
		});
	}
	if (changes.userPrefersIdentificationAsEmployee) {
		const userPrefersIdentificationAsEmployee = changes.userPrefersIdentificationAsEmployee;
		if (userPrefersIdentificationAsEmployee.newValue) {
			browser.alarms.create('checkAeaTokenExpiryAndRefreshIfAppropriate', {
				periodInMinutes: checkAeaTokenExpiryAndRefreshIfAppropriatePeriodInMinutes
			});
			checkAeaTokenExpiryAndRefreshIfAppropriate();
		} else {
			browser.alarms.clear('checkAeaTokenExpiryAndRefreshIfAppropriate');
			removeOldRules();
		}
	}

	if (changes.isInternalFeatureEnabled) {
		const isInternalFeatureEnabled = changes.isInternalFeatureEnabled.newValue;
		if (!isInternalFeatureEnabled) {
			browser.alarms.clear('checkAeaTokenExpiryAndRefreshIfAppropriate');
			removeOldRules();
		}
	}

	//check if managed storage has changed if we haven't received config
	if (!await getLocal("config_received").config_received && area == "managed") {
		await extensionPolicyConfigCheck();
	}
});



// connect to content scripts
var np = browser.runtime.connectNative("amazon_enterprise_access");
np.uuid = crypto.randomUUID();

function onDisconnectListener() {
	logToConsole(`The port with UUID ${np.uuid} disconnected. Resetting it.`)
	np = browser.runtime.connectNative("amazon_enterprise_access");
	np.uuid = crypto.randomUUID();
	np.onDisconnect.addListener(onDisconnectListener);
	logToConsole(`New port with UUID ${np.uuid} created.`)
}

np.onDisconnect.addListener(onDisconnectListener)
browser.runtime.onConnect.addListener((p) => connected(p));


/*
* Connection to content scripts
* @param p - Port object to page conten script
*/
function connected(p) {
	logToConsole(`connected to content script in tab: ${p.sender.url}}`)
	p.onDisconnect.addListener(contentPortDisconnectListener);
	p.onMessage.addListener(async (message, p, sendResponse) => {
		logToConsole(`Received message: ${JSON.stringify(message)} from ${p.sender.url}.`);
		// only come from local test page. update tab id
		if (message.type == 'RequestHealthCheck') {
			try {
				await healthCheck(p);
			}
			catch (e) {
				//Native host not exist
				sendHealthStatusToContentScript(p, { ExtensionConnected: false }, "ExtensionConnected");
			}
		}
		let nativeMessagingTransactionIdsSupported = false;
		try {
			nativeMessagingTransactionIdsSupported = (await getLocal("acme_supports_transaction_ids")).acme_supports_transaction_ids;
		} catch (error) {
			logToConsole(`Error getting acme_supports_transaction_ids from local storage: ${error}`);
		}
		if (message.type == "create") {
			var currentAuthTabId = (await getLocal("current_auth_tab")).current_auth_tab;
			var currentAuthWindowId = (await getLocal("current_auth_window")).current_auth_window;
			if (currentAuthTabId && currentAuthWindowId) {
				try {
					var tab = await browser.tabs.get(currentAuthTabId);
					var auth_domains = (await getLocal("auth_domains")).auth_domains;
					//if the tab still contains one of the auth domains.
					if (auth_domains.includes(getBaseUrl(tab.url))) {
						logToConsole(`Current auth tab and window exists ${currentAuthTabId}. Updating and focusing`);
						browser.windows.update(currentAuthWindowId, {
							focused: true,
						});
						browser.tabs.update(currentAuthTabId, {
							active: true,
						});
					}
					else {
						logToConsole(`User has navigated away from domain in currentAuthTabId. Opening new auth window`);
						//Open a new Auth Window.
						await openAuthWindow(message);
					}
				} catch(e) {
					//error finding a tab with current Auth tab id. Open a new one.
					await openAuthWindow(message);
				}
			}
			else {
				//If no auth tab/window are currently present. open a new one.
				await openAuthWindow(message);
			}
		}
		else if (message.type == "update") {
			var authTabs = new Set((await getLocal("auth_tabs")).auth_tabs);
			logToConsole(`Adding ${p.sender.url} tab to authTabs`);
			authTabs.add(p.sender.tab.id);
			await setLocal({"auth_tabs": Array.from(authTabs)});
		}
		else if (message.type == "pollConfig") {
			try {
				var configForCS = {};
				configForCS.authDomain = (await getLocal("auth_domains")).auth_domains;
				configForCS.ttLink = (await getLocal("tt_link")).tt_link;
				configForCS.patchBlackList = (await getLocal("patch_blacklist")).patch_blacklist;
				p.postMessage({ message: configForCS, type: "Configuration" });
			} catch (e) { onError(`connected:192 - ${e}`); }
		}
		else if (message.type == "pollJwt"){
			// Content script is requesting for jwt to be in cookie store
			try {
				logToConsole('Polling for jwt due to request from Midway auth page');
				let noRetry = false;
				if (message.content["noRetry"]) {
					noRetry = message.content["noRetry"];
				}
				await pollJwt(p, noRetry);
			} catch (e) {
				//Native host not exist
				let pollJwtResult = {jwtInStore : false, jwtMessage: "Unable to connect to native host"};
				p.postMessage({ message: pollJwtResult, type: "PollJwt" });
				onError(e);
			}
		}
		else if (message.type == "mcsSessionKeyPairPublicKeyRequested") {
			logToConsole("mcsSessionKeyPairPublicKeyRequested event received")
			logToConsole("communicating with ACME daemon")
			const isEnabled = await checkMcsIntegrationEnabledAndPostMessageIfNot(p, "mcsSessionKeyPairPublicKeyReturned");
			if (!isEnabled) {
				return;
			}
			var response;
			try {
				if (nativeMessagingTransactionIdsSupported) {
					response = await sendNativePortMessage(np, "getMcsSessionKeyPairPublicKeyAndKeyId");
				} else {
					response = await nativeMessageTimeout("getMcsSessionKeyPairPublicKeyAndKeyId", 15000);
				}
			} catch (error) {
				logToConsole(`Error communicating with ACME daemon - ${error}`);
				p.postMessage({ message: {"Status": `Failed - ${error}`, "ResultCode": 99}, type: "mcsSessionKeyPairPublicKeyReturned" });
				return;
			}
			logToConsole("returning response")
			p.postMessage({ message: response, type: "mcsSessionKeyPairPublicKeyReturned" });
			return
		}
		else if (message.type == "sessionTokenRequested") {
			logToConsole("sessionTokenRequested event received")
			logToConsole("communicating with ACME daemon")
			const isEnabled = await checkMcsIntegrationEnabledAndPostMessageIfNot(p, "sessionTokenReturned");
			if (!isEnabled) {
				return;
			}
			const cmd = `getMcsSessionToken --idp-hostname ${message.content.idpHostname}`;
			var response;
			try {
				if (nativeMessagingTransactionIdsSupported) {
					response = await sendNativePortMessage(np, cmd);
				} else {
					response = await nativeMessageTimeout(cmd, 15000);
				}
				if (response.Status == "Success") {
					const cookieDetails = {
						url: "https://" + message.content.idpHostname,
						name: 'session',
						value: response.SessionToken,
						httpOnly: true,
						expirationDate: response.Exp
					};
					await browser.cookies.set(cookieDetails);
				}
			} catch (error) {
			  logToConsole(`Error communicating with ACME daemon or setting cookie - ${error}`);
				p.postMessage({ message: {"Status": `Failed - ${error}`, "ResultCode": 99}, type: "sessionTokenReturned" });
				return;
			}
			logToConsole("returning response")
			p.postMessage({ message: response, type: "sessionTokenReturned" });
			return;
		}
		else if (message.type == "authorizeRequested" || message.type == "authorizeRequestedSentryJS") {
			logToConsole(`${message.type} event received`)
			logToConsole("communicating with ACME daemon")
			const isEnabled = await checkMcsIntegrationEnabledAndPostMessageIfNot(p, "authorizeReturned");
			if (!isEnabled) {
				return;
			}
			const authorizeUrl = message.content.authorizeUrl;
			logToConsole(`authorizeUrl: ${new URL(authorizeUrl).host}`);
			const cmd = `performMcsAuthorization --authorize-url ${authorizeUrl}`;
			var response;
			try {
				if (nativeMessagingTransactionIdsSupported) {
					response = await sendNativePortMessage(np, cmd, 15000);
				} else {
					response = await nativeMessageTimeout(cmd, 15000);
				}
			} catch (error) {
				logToConsole(`Error communicating with ACME daemon - ${error}`);
				p.postMessage({ message: {"Status": `Failed - ${error}`, "ResultCode": 99}, type: "authorizeReturned" });
				return;
			}

			if (message.type == "authorizeRequestedSentryJS" && response.CallbackUrl) {
				const idToken = parseIdTokenFromCallbackUrlIfItExists(response.CallbackUrl);
				// Set Id token
				if (idToken !== null) {
					const origin = new URL(response.CallbackUrl).origin
					const ssoLogin = new URL(origin);
					ssoLogin.pathname = '/sso/login';
					ssoLogin.searchParams.set('id_token', idToken);
					await fetch(ssoLogin.toString(), {credentials: 'include'});
				}
			}

			logToConsole("returning response")
			p.postMessage({ message: response, type: "authorizeReturned" });
		}
		else if (message.type === "saveSessionTokenRequested") {
			logToConsole("saveSessionTokenRequested event received")
			logToConsole("communicating with ACME daemon")
			const isEnabled = await checkMcsIntegrationEnabledAndPostMessageIfNot(p, "saveSessionTokenReturned");
			if (!isEnabled) {
				return;
			}
			const sessionCookieObject = await browser.cookies.get({url: message.content.idpUrl, name: "session"});
			const sessionCookieValue = sessionCookieObject.value;
			const sessionCookieExpiry = Math.floor(sessionCookieObject.expirationDate);
			const sessionKeyPairKeyId = message.content.sessionKeyPairKeyId;
			const cmd = `saveMcsSessionToken --idp-hostname ${message.content.idpHostname} --session-token ${sessionCookieValue} --expiration-time ${sessionCookieExpiry} --key-id ${sessionKeyPairKeyId}`;
			var response;
			try {
				// We don't want to log the command here because it contains the session token. Hence, logCommand (the fourth parameter) is set to false.
				if (nativeMessagingTransactionIdsSupported) {
					response = await sendNativePortMessage(np, cmd);
				} else {
					response = await nativeMessageTimeout(cmd, 15000, false);
				}
			} catch (error) {
				logToConsole(`Error communicating with ACME daemon - ${error}`);
				p.postMessage({ message: {"Status": `Failed - ${error}`, "ResultCode": 99}, type: "saveSessionTokenReturned" });
				return;
			}
			logToConsole("returning response")
			p.postMessage({ message: response, type: "saveSessionTokenReturned" });
		}
		else if (message.type == "deleteSessionTokenRequested") {
			logToConsole("deleteSessionTokenRequested event received")
			logToConsole("communicating with ACME daemon")
			const isEnabled = await checkMcsIntegrationEnabledAndPostMessageIfNot(p, "deleteSessionTokenReturned");
			if (!isEnabled) {
				return;
			}
			const fiveSecondsInTheFutureEpochTimeInteger = Math.floor(Date.now() / 1000) + 5;
			const fakeSessionCookieValue = "fakesessiontoken";
			const fakeKeyId = "A1A1A1A1-A1A1-A1A1-A1A1-A1A1A1A1A1A1";
			const cmd = `saveMcsSessionToken --idp-hostname ${message.content.idpHostname} --session-token ${fakeSessionCookieValue} --expiration-time ${fiveSecondsInTheFutureEpochTimeInteger} --key-id ${fakeKeyId}`;
			var response;
			try {
				if (nativeMessagingTransactionIdsSupported) {
					response = await sendNativePortMessage(np, cmd);
				} else {
					response = await nativeMessageTimeout(cmd, 15000, false);
				}
			} catch (error) {
				logToConsole(`Error communicating with ACME daemon - ${error}`);
				p.postMessage({ message: {"Status": `Failed - ${error}`, "ResultCode": 99}, type: "deleteSessionTokenReturned" });
				return;
			}
			logToConsole("returning response")
			p.postMessage({ message: response, type: "deleteSessionTokenReturned" });
			return
		}
		else if (message.type == "pollAuthSuccess") {
			// Content script polls the current auth successful event.
			// Content script will compare it with
			try {
				var currentAuthSuccessfulEvent = (await getLocal("current_auth_event")).current_auth_event;
				p.postMessage({ message: currentAuthSuccessfulEvent, type: "AuthSuccess" });
			} catch (e) { onError(`connected:200 - ${e}`); }
		}
		else if (message.type == "updateAuthSuccess") {
			if (currentAuthWindowId) {
				try {
					logToConsole(`Removing ${currentAuthTabId}, removed message: updateAuthSuccess`);
					browser.tabs.remove(currentAuthTabId).then(onAuthWindowRemoved, onError);
				} catch(e) { onError(`connected:207 - ${e}`); }
			}
			else {
				onAuthWindowRemoved();
			}
			await setLocal({"current_auth_event": message.content});
		}
		else if (message.type == "pollMidwayRevampFlag"){
			let response = await getLocal("shouldRevampPostureErrorPages");
			p.postMessage({ message: response.shouldRevampPostureErrorPages, type: "pollMidwayRevampFlagResult" });
		}
	});
}

browser.tabs.onRemoved.addListener(async (tabId) => {
	if (tabId == (await getLocal("current_auth_tab")).current_auth_tab) {
		await removeLocal(["current_auth_tab", "current_auth_window"]);
	}
});

browser.cookies.onChanged.addListener(async (changeInfo) => {
	var cookieName = (await getLocal("default_cookie_name")).default_cookie_name;
	if (changeInfo.cause == "overwrite" || !changeInfo.removed || changeInfo.cookie.name != cookieName) return;
	logToConsole(`Cookie ${cookieName} (${changeInfo.cookie.domain}) changed: ` +
			'\n * Cause: ' + changeInfo.cause +
			'\n * Removed: ' + changeInfo.removed);
	logToConsole("detected AEA cookie removal, calling poll jwt.");
	onCookieDelete();
});

const onCookieDelete = debounce(async () => await pollJwt());
/*
Context menu for extension
*/
browser.contextMenus.onClicked.addListener(async function (info, tab) {
	switch (info.menuItemId) {
		case "refresh":
			await pollJwt();
			break;
		case "perform-health-check":
			browser.tabs.create({
				"url": (await getLocal("extension_url")).extension_url.concat("index.html")
			});
			break;
		case "about":
			browser.tabs.create({
				"url": (await getLocal("extension_url")).extension_url.concat("about.html")
			});
	}
});

async function checkAeaTokenExpiryAndRefreshIfAppropriate() {
	const { isInternalFeatureEnabled } = await browser.storage.local.get({ isInternalFeatureEnabled: false });
	if (!isInternalFeatureEnabled) {
		return;
	}
	const { userPrefersIdentificationAsEmployee } = await browser.storage.local.get({ userPrefersIdentificationAsEmployee: false });
	if (!userPrefersIdentificationAsEmployee) {
		return;
	}
	const { aeaIsInternalJwtCurrentlyUsedInRules } = await browser.storage.local.get({ aeaIsInternalJwtCurrentlyUsedInRules: null });
	var shouldRefresh = false;
	if (aeaIsInternalJwtCurrentlyUsedInRules == null) { shouldRefresh = true }
	if (aeaIsInternalJwtCurrentlyUsedInRules != null) {
		try {
			const expiryTimeInSeconds = jwtDecode(aeaIsInternalJwtCurrentlyUsedInRules).exp
			const currentTimeInSeconds = Math.floor(Date.now() / 1000)
			const timeLeftInSeconds = expiryTimeInSeconds - currentTimeInSeconds
			const bufferTimeForTokenRefresh = 1 * 60 * 60
			if (timeLeftInSeconds < bufferTimeForTokenRefresh) {
				shouldRefresh = true;
			}
		} catch(e) {
			logToConsole("Error while decoding jwt: ", e, ". Refreshing jwt and rules.");
			shouldRefresh = true;
		}
	}
	if (shouldRefresh) {
		const jwt = await getAeaIsInternalJwt();
		if (!jwt) {
			console.error("Unable to fetch jwt. Not refreshing rules.");
			return;
		}
		await addNewRulesToEnableIdentificationAsEmployee(jwt);
		await browser.storage.local.set({ aeaIsInternalJwtCurrentlyUsedInRules: jwt });
	}
}

browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
	if (message.action === 'refresh') {
		logToConsole("Received refresh message from popup. Calling pollJwt.");
		pollJwt();
	}
});

// Only export if we're in a NodeJS environment
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        connected
    };
} 