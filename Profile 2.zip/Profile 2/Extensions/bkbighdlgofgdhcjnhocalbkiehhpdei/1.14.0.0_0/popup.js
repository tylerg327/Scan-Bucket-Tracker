/** 
 * A utility function that returns a promise which resolves once the DOM can be interacted with, or 
 * immediately if the DOM is already loaded.
 */
const domIsReady = async () => {
  return new Promise((res) => {
    if (document.body) { res() } // resolve immediately
    else {
      document.addEventListener("DOMContentLoaded", () => { res() }); // resolve when the DOM is loaded
    }
  });
};

const isManifestV2 = () => {
  const manifest = browser.runtime.getManifest();
  return manifest.manifest_version === 2;
}

const configureInitialStateOfLabelBasedOnUserPreference = (userPrefersIdentificationAsEmployee) => {
  const input = document.querySelector("#is-internal-permissions-input");
  if (input) {
    input.checked = userPrefersIdentificationAsEmployee;
  }
}

const addEventListener = () => {
  document.querySelector("#is-internal-permissions-input")?.addEventListener("change", async (e) => {
    const userPrefersIdentificationAsEmployee = e.target.checked;
    browser.storage.local.set({ userPrefersIdentificationAsEmployee });
    if (userPrefersIdentificationAsEmployee) {
      browser.permissions.request({ origins: ["<all_urls>"] });
    }
    e.target.disabled = true;
    setTimeout(() => {
      e.target.disabled = false;
    }, 2000);
  });
}

const removeIsInternalPreferenceToggle = () => {
  const request = document.querySelector("#is-internal-permissions-request");
  if (request) {
    request.remove();
  }
}

const requestHostPermissions = async () => {
  const hostOrigins = browser.runtime.getManifest().host_permissions;
  browser.permissions.request({ origins: hostOrigins });
}

const thereAreMissingHostPermissions = async () => {
  if (isManifestV2()) {
    // Cannot disable required host permissions for manifest v2 extensions.
    return false;
  }

  const hostOrigins = browser.runtime.getManifest().host_permissions;
  const permissions = await browser.permissions.getAll();
  if (permissions.origins.includes('<all_urls>')) {
    return false;
  }
  return hostOrigins.some((origin) => !permissions.origins.includes(origin));
}

const browser = window.browser || window.chrome;

const main = async() => {
  const { isInternalFeatureEnabled } = await browser.storage.local.get({ isInternalFeatureEnabled: false });
  const { userPrefersIdentificationAsEmployee } = await browser.storage.local.get({ userPrefersIdentificationAsEmployee: false });
  await domIsReady();
  configureInitialStateOfLabelBasedOnUserPreference(userPrefersIdentificationAsEmployee);
  if (!isInternalFeatureEnabled) {
    console.log("Removing isInternalPermissionsRequest")
    removeIsInternalPreferenceToggle();
  }
  addEventListener();
  if (await thereAreMissingHostPermissions()) {
    document.querySelector("#host-permissions-request").classList.remove("hidden");
    document.querySelector("#host-permissions-request-button").addEventListener("click", requestHostPermissions);
  }
  document.querySelector("#refresh-button").addEventListener("click", () => {
    browser.runtime.sendMessage({ action: "refresh" });
    window.close();
  });
}

main();