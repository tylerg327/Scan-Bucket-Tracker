
/**
* @file Page script that is injected on websites using SentryJS by AEA Extension to 
authenticate Midway AJAX requests
* @author Mary Alula <maralula@amazon.com>
*/

const callAuthorize = async(authorizeUrl) => {
    if (!authorizeUrl) {
        return Promise.reject('Invalid authorize url');
    }
    const expectedHost = getRedirectURIHostFromAuthorizeUrlIfItExists(authorizeUrl);

    if (!expectedHost) {
        return Promise.reject('Invalid Authorize URL. Could not parse Redirect URI');
    }

    var responsePromise = new Promise((resolve, reject) => {
        function handleEvent(event) {
            console.log("Received authorizedReturned response from background script");

            if (event.detail.host === expectedHost && event.detail.resultCode === 0) {
                window.removeEventListener('authorizeReturnedSentryJS', handleEvent);
                resolve(event.detail);
            } else if (event.detail.resultCode !== 0) {
                window.removeEventListener('authorizeReturnedSentryJS', handleEvent);
                reject(event.detail);
            }
        }
        // content-script will emit this event based on the response it gets from the background script or extension
        window.addEventListener('authorizeReturnedSentryJS', handleEvent);
    });

    document.dispatchEvent(new CustomEvent('authorizeRequested', {
        detail: {
            authorizeUrl
        }
    }));

    return responsePromise;
};

function getRedirectURIHostFromAuthorizeUrlIfItExists(authorizeUrl) {
	let url = null;
	try {
        url = new URL(authorizeUrl);
    } catch (e) {
        console.error(e);
        return null;
    }
	const parsedRedirectURI = url.searchParams.get('redirect_uri');

	if (parsedRedirectURI) {
		const decodedRedirectURI = decodeURI(parsedRedirectURI);
		const redirectURL = new URL(decodedRedirectURI);
		return redirectURL.host;
	} else {
		return null;
	}
}


// Only export if we're in a NodeJS environment
if (typeof module !== 'undefined' && module.exports) {
	module.exports = {
		callAuthorize
    }
} 
	
